/*
  ======================
  Mencari yang terpintar
  ======================
  
  Buatlah algoritma atau pseudocode untuk mencari semua angka diatas rata-rata.
  Data yang diberikan berupa satu set angka dari nilai ujian murid-murid
  di kelas.
*/